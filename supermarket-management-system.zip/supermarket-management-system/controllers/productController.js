const Product = require("../models/Product");

// Create
exports.createProduct = async (req, res) => {
    try {
        const product = await Product.create(req.body);

        res.status(201).json(product);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Read All
exports.getProducts = async (req, res) => {
    try {
        const products = await Product.find()
            .populate("category")
            .populate("supplier");

        res.json(products);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Read By ID
exports.getProductById = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id)
            .populate("category")
            .populate("supplier");

        if (!product) {
            return res.status(404).json({
                message: "Product not found"
            });
        }

        res.json(product);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Update
exports.updateProduct = async (req, res) => {
    try {
        const product = await Product.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );

        res.json(product);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Delete
exports.deleteProduct = async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);

        res.json({
            message: "Product deleted successfully"
        });
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
};