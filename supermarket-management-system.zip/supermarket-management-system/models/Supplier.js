const mongoose = require("mongoose");

const supplierSchema = new mongoose.Schema({
  supplierName: String,
  phone: String,
  email: String,
  address: String
});

module.exports = mongoose.model("Supplier", supplierSchema);