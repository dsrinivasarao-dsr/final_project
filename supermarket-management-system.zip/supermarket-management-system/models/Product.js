const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
{
    productName: {
        type: String,
        required: true
    },

    price: {
        type: Number,
        required: true
    },

    stockQuantity: {
        type: Number,
        required: true
    },

    expiryDate: {
        type: Date
    },

    category: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Category",
        required: true
    },

    supplier: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Supplier",
        required: true
    }
},
{
    timestamps: true
});

module.exports = mongoose.model("Product", productSchema);