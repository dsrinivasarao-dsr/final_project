# Supermarket Management System

## Project Overview

The Supermarket Management System is a backend application developed using Node.js, Express.js, MongoDB, and Mongoose. The system helps manage supermarket operations such as Category Management, Customer Management, Supplier Management, and Product Management through REST APIs.

The application demonstrates CRUD (Create, Read, Update, Delete) operations and MongoDB collection relationships using Mongoose.

## Technologies Used

* Node.js
* Express.js
* MongoDB
* Mongoose
* Postman
* dotenv
* cors

## Project Structure

supermarket-management-system

├── models

│ ├── Category.js

│ ├── Customer.js

│ ├── Supplier.js

│ └── Product.js

├── controllers

│ ├── categoryController.js

│ ├── customerController.js

│ ├── supplierController.js

│ └── productController.js

├── routes

│ ├── categoryRoutes.js

│ ├── customerRoutes.js

│ ├── supplierRoutes.js

│ └── productRoutes.js

├── .env

├── server.js

├── package.json

└── README.md

## Features

### Category Management

* Add Category
* View Categories
* Update Category
* Delete Category

### Customer Management

* Add Customer
* View Customers
* Update Customer
* Delete Customer

### Supplier Management

* Add Supplier
* View Suppliers
* Update Supplier
* Delete Supplier

### Product Management

* Add Product
* View Products
* Update Product
* Delete Product

## MongoDB Relationships

* One Category → Many Products
* One Supplier → Many Products

## API Endpoints

### Categories

POST /api/categories

GET /api/categories

GET /api/categories/:id

PUT /api/categories/:id

DELETE /api/categories/:id

### Customers

POST /api/customers

GET /api/customers

GET /api/customers/:id

PUT /api/customers/:id

DELETE /api/customers/:id

### Suppliers

POST /api/suppliers

GET /api/suppliers

GET /api/suppliers/:id

PUT /api/suppliers/:id

DELETE /api/suppliers/:id

### Products

POST /api/products

GET /api/products

GET /api/products/:id

PUT /api/products/:id

DELETE /api/products/:id

## Installation

1. Clone the repository

git clone <repository-url>

2. Install dependencies

npm install

3. Configure environment variables

Create a .env file:

MONGO_URI=your_mongodb_connection_string

PORT=5000

4. Run the application

node server.js

5. Test APIs using Postman

## Expected Outcome

The system provides a centralized backend solution for managing supermarket data. It demonstrates MongoDB CRUD operations, API development using Express.js, and collection relationships using Mongoose.
